import { Component } from '@angular/core';
import { TopicListPageComponent as BaseComponent } from '../../../../app/topic-list-page/topic-list-page.component';

@Component({
  selector: 'ds-topic-list-page',
  // styleUrls: ['./topic-list-page.component.scss'],
  // templateUrl: './topic-list-page.component.html'
  templateUrl: '../../../../app/topic-list-page/topic-list-page.component.html',
})

/**
 * Page with title and the topic list tree, as described in topic-list.component;
 * navigated to with topic-list.page.routing.module
 */
export class TopicListPageComponent extends BaseComponent {}
