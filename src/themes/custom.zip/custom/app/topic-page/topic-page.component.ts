import { ChangeDetectionStrategy, Component } from '@angular/core';
import { TopicPageComponent as BaseComponent } from '../../../../app/topic-page/topic-page.component';
import { fadeInOut } from '../../../../app/shared/animations/fade';

@Component({
  selector: 'ds-topic-page',
  // templateUrl: './topic-page.component.html',
  templateUrl: '../../../../app/topic-page/topic-page.component.html',
  // styleUrls: ['./topic-page.component.scss']
  styleUrls: ['../../../../app/topic-page/topic-page.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [fadeInOut],
})
/**
 * This component represents a detail page for a single community
 */
export class TopicPageComponent extends BaseComponent {}
