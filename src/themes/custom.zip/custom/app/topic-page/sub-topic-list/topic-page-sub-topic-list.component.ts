import { Component } from '@angular/core';
import { TopicPageSubTopicListComponent as BaseComponent } from '../../../../../app/topic-page/sub-topic-list/topic-page-sub-topic-list.component';

@Component({
  selector: 'ds-topic-page-sub-topic-list',
  // styleUrls: ['./topic-page-sub-topic-list.component.scss'],
  styleUrls: [
    '../../../../../app/topic-page/sub-topic-list/topic-page-sub-topic-list.component.scss',
  ],
  // templateUrl: './topic-page-sub-topic-list.component.html',
  templateUrl:
    '../../../../../app/topic-page/sub-topic-list/topic-page-sub-topic-list.component.html',
})
export class TopicPageSubTopicListComponent extends BaseComponent {}
