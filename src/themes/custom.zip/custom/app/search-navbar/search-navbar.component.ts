import { Component } from '@angular/core';
import { SearchNavbarComponent as BaseComponent } from '../../../../app/search-navbar/search-navbar.component';

@Component({
  selector: 'ds-search-navbar',
  // styleUrls: ['./search-navbar.component.scss'],
  styleUrls: ['../../../../app/search-navbar/search-navbar.component.scss'],
  // templateUrl: './search-navbar.component.html'
  templateUrl: '../../../../app/search-navbar/search-navbar.component.html'
})
export class SearchNavbarComponent extends BaseComponent {

}
