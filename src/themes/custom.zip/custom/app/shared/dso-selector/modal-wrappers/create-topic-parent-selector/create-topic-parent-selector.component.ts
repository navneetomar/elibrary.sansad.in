import { Component } from '@angular/core';
import { CreateTopicParentSelectorComponent as BaseComponent } from '../../../../../../../app/shared/dso-selector/modal-wrappers/create-topic-parent-selector/create-topic-parent-selector.component';

@Component({
  selector: 'ds-create-topic-parent-selector',
  // styleUrls: ['./create-topic-parent-selector.component.scss'],
  styleUrls: [
    '../../../../../../../app/shared/dso-selector/modal-wrappers/create-topic-parent-selector/create-topic-parent-selector.component.scss',
  ],
  // templateUrl: './create-topic-parent-selector.component.html',
  templateUrl:
    '../../../../../../../app/shared/dso-selector/modal-wrappers/create-topic-parent-selector/create-topic-parent-selector.component.html',
})
export class CreateTopicParentSelectorComponent extends BaseComponent {}
