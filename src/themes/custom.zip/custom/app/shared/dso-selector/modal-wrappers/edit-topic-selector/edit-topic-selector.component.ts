import { Component } from '@angular/core';
import { EditTopicSelectorComponent as BaseComponent } from '../../../../../../../app/shared/dso-selector/modal-wrappers/edit-topic-selector/edit-topic-selector.component';

@Component({
  selector: 'ds-edit-topic-selector',
  // styleUrls: ['./edit-topic-selector.component.scss'],
  // templateUrl: './edit-topic-selector.component.html',
  templateUrl:
    '../../../../../../../app/shared/dso-selector/modal-wrappers/dso-selector-modal-wrapper.component.html',
})
export class EditTopicSelectorComponent extends BaseComponent {}
